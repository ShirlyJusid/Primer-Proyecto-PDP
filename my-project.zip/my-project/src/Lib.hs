--En una plantación de pinos, de cada árbol se conoce la altura expresada en metros. El peso de un pino se puede calcular a partir de la altura así:
--3 kg por cada centímetro hasta 3 metros,
--2 kg por cada centímetro arriba de los 3 metros.
--Ejemplos
--Un pino de 2 metros pesa 600 kg, porque 200 * 3 = 600
--Un pino de 5 metros pesa 1300 kg, porque los primeros 3 metros pesan 900 kg y los siguientes 2 pesan los 400 restantes.

--Se pide
--Definí la función pesoPino, que recibe la altura de un pino en metros y devuelve su peso. Pista: las funciones max o min pueden serte de ayuda.
--Los pinos se usan para llevarlos a una fábrica de muebles, a la que le sirven árboles de entre 400 y 1000 kilos, un pino fuera de este rango no le sirve a la fábrica. Definí la función esPesoUtil, que recibe un peso en kg y responde si un pino de ese peso le sirve a la fábrica
--Definí la función sirvePino, que recibe la altura de un pino y responde si un pino de ese peso le sirve a la fábrica.

module Lib
    ( pesoPino,
      esPesoUtil,
      sirvePino
    ) where


pesoPino :: Float -> Float
pesoPino altura = 
    let alturaCm= altura*100
        pesoHasta3m = (min alturaCm 300) * 3 
        pesoSobre3m = max (alturaCm - 300) 0 * 2 
    in pesoHasta3m + pesoSobre3m

esPesoUtil :: Float -> Bool
esPesoUtil peso = peso >= 400 && peso <= 1000

sirvePino :: Float -> String
sirvePino altura = 
    let peso = pesoPino altura
    in if esPesoUtil peso
        then "El pino le sirve a la fabrica"
        else "El pino no le sirve a la fabrica"